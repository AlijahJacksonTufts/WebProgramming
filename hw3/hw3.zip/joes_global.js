export const PRICE_HOTDOG = 5.25;
export const PRICE_FRIES = 3.75;
export const PRICE_SODA = 2.50;
export const MEAL_DEAL_PRICE = 10.00;
export const DISCOUNT_MEAL_RATE = 0.1;
export const DISCOUNT_MEAL_THRESHOLD = 30.00; 
export const TAX_RATE = 0.0625;